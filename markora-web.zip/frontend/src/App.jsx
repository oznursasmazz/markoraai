import { useState } from 'react';

export default function App() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');

  const sendMessage = async () => {
    if (!input) return;
    setMessages([...messages, { sender: 'Sen', text: input }]);
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: input })
    });
    const data = await res.json();
    setMessages([...messages, { sender: 'Sen', text: input }, { sender: 'Markora AI', text: data.reply }]);
    setInput('');
  };

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold text-blue-700 mb-4">Markora AI Çözüm Otomatı</h1>
      <div className="border p-4 h-96 overflow-y-scroll bg-white rounded mb-4">
        {messages.map((m, i) => (
          <p key={i}><b>{m.sender}:</b> {m.text}</p>
        ))}
      </div>
      <div className="flex">
        <input
          className="flex-1 border p-2 rounded"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Sorunuzu yazın..."
        />
        <button className="ml-2 bg-blue-700 text-white px-4 rounded" onClick={sendMessage}>Gönder</button>
      </div>
    </div>
  );
}